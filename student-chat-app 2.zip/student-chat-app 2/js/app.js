// Mock Data Store
let users = [
  { id: '111', name: 'Alice Smith', major: 'Computer Science', code: 'test', hobbies: 'Coding, Reading', avatar: 'https://i.pravatar.cc/150?u=1', msgCount: 245 },
  { id: '222', name: 'Bob Jones', major: 'Engineering', code: 'test', hobbies: 'Football, Math', avatar: 'https://i.pravatar.cc/150?u=2', msgCount: 120 },
  { id: '333', name: 'Charlie Brown', major: 'Business', code: 'test', hobbies: 'Music, Travel', avatar: 'https://i.pravatar.cc/150?u=3', msgCount: 89 },
  { id: '444', name: 'Diana Prince', major: 'Arts', code: 'test', hobbies: 'Painting, History', avatar: 'https://i.pravatar.cc/150?u=4', msgCount: 15 },
];

let messages = {};

// Demo User setup
const currentUser = { id: 'demo', name: 'You (Demo User)', avatar: 'https://i.pravatar.cc/150?u=demo' };
let activeChatUserId = '111';

// Init on page load
window.addEventListener('DOMContentLoaded', () => {
  renderPodium();
  renderUserList(users);
  selectUser(users[0]);
});

// Chat Demo functions
function renderUserList(list) {
  const container = document.getElementById('usersList');
  if(!container) return;
  container.innerHTML = '';
  list.forEach(user => {
    const div = document.createElement('div');
    div.className = `user-item ${activeChatUserId === user.id ? 'active' : ''}`;
    div.onclick = () => selectUser(user);
    div.innerHTML = `
      <img src="${user.avatar}" alt="${user.name}">
      <div class="user-details">
        <h4>${user.name}</h4>
        <p>${user.major}</p>
      </div>
    `;
    container.appendChild(div);
  });
}

function filterUsers() {
  const query = document.getElementById('searchInput').value.toLowerCase();
  const filtered = users.filter(u => u.name.toLowerCase().includes(query) || u.major.toLowerCase().includes(query));
  renderUserList(filtered);
}

function selectUser(user) {
  activeChatUserId = user.id;
  document.getElementById('activeChatAvatar').src = user.avatar;
  document.getElementById('activeChatName').innerText = user.name;
  document.getElementById('activeChatMajor').innerText = `${user.major} | Hobbies: ${user.hobbies}`;
  
  filterUsers(); // Re-render to update active class
  renderMessages();
}

function getChatKey(id1, id2) {
  return [id1, id2].sort().join('_');
}

function renderMessages() {
  const chatBox = document.getElementById('chatBox');
  if(!chatBox) return;
  chatBox.innerHTML = '';
  
  if (!activeChatUserId) return;
  
  const key = getChatKey(currentUser.id, activeChatUserId);
  
  // Create some default messages for demo
  if (!messages[key]) {
    messages[key] = [
      { senderId: activeChatUserId, text: `Hey! Are you working on the ${users.find(u=>u.id===activeChatUserId).major} assignment?` },
      { senderId: currentUser.id, text: `Yes, just finished part 1. How about you?` }
    ];
  }

  const chatHistory = messages[key];

  chatHistory.forEach(msg => {
    const div = document.createElement('div');
    div.className = `message ${msg.senderId === currentUser.id ? 'sent' : 'received'}`;
    div.innerText = msg.text;
    chatBox.appendChild(div);
  });
  
  chatBox.scrollTop = chatBox.scrollHeight;
}

function handleKeyPress(e) {
  if (e.key === 'Enter') {
    sendMessage();
  }
}

function sendMessage() {
  if (!activeChatUserId) return;
  const input = document.getElementById('messageInput');
  const text = input.value.trim();
  
  if (text) {
    const key = getChatKey(currentUser.id, activeChatUserId);
    if (!messages[key]) messages[key] = [];
    
    messages[key].push({ senderId: currentUser.id, text: text });
    
    input.value = '';
    renderMessages();
    
    // Auto-reply simple mock for effect
    setTimeout(() => {
      messages[key].push({
        senderId: activeChatUserId,
        text: "That sounds interesting! Let's discuss it later."
      });
      renderMessages();
    }, 1500);
  }
}

// Podium functionality
function renderPodium() {
  const sortedUsers = [...users].sort((a, b) => b.msgCount - a.msgCount);
  
  const top3Area = document.getElementById('top3Area');
  const listArea = document.getElementById('leaderboardList');
  if(!top3Area || !listArea) return;
  
  if(sortedUsers.length >= 3) {
    top3Area.innerHTML = `
      <div class="podium-place place-2">
        <img src="${sortedUsers[1].avatar}" class="podium-avatar">
        <div class="podium-step">2</div>
        <h4>${sortedUsers[1].name}</h4>
        <p>${sortedUsers[1].msgCount} msgs</p>
      </div>
      <div class="podium-place place-1">
        <img src="${sortedUsers[0].avatar}" class="podium-avatar">
        <div class="podium-step">1</div>
        <h4>${sortedUsers[0].name}</h4>
        <p>${sortedUsers[0].msgCount} msgs</p>
      </div>
      <div class="podium-place place-3">
        <img src="${sortedUsers[2].avatar}" class="podium-avatar">
        <div class="podium-step">3</div>
        <h4>${sortedUsers[2].name}</h4>
        <p>${sortedUsers[2].msgCount} msgs</p>
      </div>
    `;
  }
  
  listArea.innerHTML = '';
  sortedUsers.slice(3).forEach((user, index) => {
    const div = document.createElement('div');
    div.className = 'leaderboard-item';
    div.innerHTML = `
      <div class="rank">${index + 4}</div>
      <img src="${user.avatar}" alt="Avatar">
      <div class="leaderboard-info">
        <h4>${user.name}</h4>
        <p style="font-size:0.8rem; color:var(--text-dark)">${user.major}</p>
      </div>
      <div class="msg-count">${user.msgCount}</div>
    `;
    listArea.appendChild(div);
  });
}
